from ui.ui import *

if __name__ == "__main__":
    ui = Ui()
    # ui.load_map(["", "res/1.map"])
    # ui.parameter_setup(["", "res/p.txt"])
    ui.start()
